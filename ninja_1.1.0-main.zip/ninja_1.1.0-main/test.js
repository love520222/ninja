process.env.NOTIFY = false;
console.log(process.env.NOTIFY || true)